export const VOL_AND_READING_BEGIN_TIME = '2012-10'
export const OTHER_BEGIN_TIME = '2016-01'
export const MONTH_MAP = ['Jan.', 'Feb.', 'Mar.', 'Apr.', 'May.','Jun.', 
                          'Jul.', 'Aug.', 'Sep.', 'Otc.', 'Nov.', 'Dec.']

export const AUDIO_PLAY_TEXT = '收听'
export const AUDIO_PLAY_IMG = '../../../image/audio_play.png'
export const AUDIO_PAUSE_TEXT = '暂停'
export const AUDIO_PAUSE_IMG = '../../../image/audio_pause.png'

export const MUSIC_PALY_IMG = '../../../image/music_play.png'
export const MUSIC_PAUSE_IMG = '../../../image/music_pause.png'