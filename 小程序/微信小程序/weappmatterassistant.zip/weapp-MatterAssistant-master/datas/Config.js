
module.exports = {
    ITEMS_SAVE_KEY: 'todo_item_save_Key',
    LEVEL: {
        normal: 1,
        warning: 2,
        danger: 3
    }
};