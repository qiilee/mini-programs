# BS
初始化
精简版百思不得姐
blog: http://blog.csdn.net/u014360817/article/details/52753565

效果图

####段子

![image](https://github.com/shuncaigao/BS/blob/master/QQ20161008-0%E5%89%AF%E6%9C%AC.png)

####图片
![image](https://github.com/shuncaigao/BS/blob/master/QQ20161008-0.png)


####音乐
![image](https://github.com/shuncaigao/BS/blob/master/QQ20161008-1.png)


####视频
![image](https://github.com/shuncaigao/BS/blob/master/QQ20161008-2.png)





![image](https://github.com/shuncaigao/BS/blob/master/1.gif)

