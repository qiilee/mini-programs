# wechat-JD
微信小程序仿京东首页

![](./screenshot/jd_home.png)

![](./screenshot/jd-home2.png)