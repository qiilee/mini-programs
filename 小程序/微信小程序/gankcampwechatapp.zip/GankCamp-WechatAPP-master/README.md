[![@iwgang](https://img.shields.io/badge/weibo-%40iwgang-blue.svg)](http://weibo.com/iwgang)

# GankCamp-WechatAPP
干货集中营 微信 小程序版

### 运行
微信小程序开发工具‘添加项目’时，请在AppID栏选择‘无 AppID’，否则会出现获取不了数据错误.

### 截图
![](https://raw.githubusercontent.com/iwgang/GankCamp-WechatAPP/master/screenshot/all.gif)

**其它截图**  
<img src="https://raw.githubusercontent.com/iwgang/GankCamp-WechatAPP/master/screenshot/s1.png" width="400px" height="650px"/>
<img src="https://raw.githubusercontent.com/iwgang/GankCamp-WechatAPP/master/screenshot/s2.png" width="400px" height="650px"/>
<img src="https://raw.githubusercontent.com/iwgang/GankCamp-WechatAPP/master/screenshot/s3.png" width="400px" height="650px"/>
<img src="https://raw.githubusercontent.com/iwgang/GankCamp-WechatAPP/master/screenshot/s4.png" width="400px" height="650px"/>
<img src="https://raw.githubusercontent.com/iwgang/GankCamp-WechatAPP/master/screenshot/s5.png" width="400px" height="650px"/>
<img src="https://raw.githubusercontent.com/iwgang/GankCamp-WechatAPP/master/screenshot/s6.png" width="400px" height="650px"/>

### 感谢[Gank.io](http://gank.io)提供数据api
    
### License

`MIT`
