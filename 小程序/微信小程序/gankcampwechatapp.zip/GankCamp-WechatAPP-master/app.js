/**
 * app 入口
 * author：iWgang
 * email:  iwgang@163.com
 * time:   2016-10-11
 * github：https://github.com/iwgang/GankCamp-WechatAPP
 */
App({
  onLaunch: function() {
  },
})