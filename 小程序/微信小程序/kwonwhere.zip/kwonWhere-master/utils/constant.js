module.exports={
 MAIN_TYPE :{
zhanxun:'exhibition_information',
exhibition:'exhibition',
book:'book',
content:'content',
article:'video',
topic:'topic'
 }

}