module.exports={
    API_HOST:"https://www.knowhere.cn/Api"
}