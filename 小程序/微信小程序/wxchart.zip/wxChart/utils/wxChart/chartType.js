/**
 * 定义painter类型
 */
var chartType = {
    test : "test",
    brokenLine : "brokenLine",
    pie:"pie",
    mycandlestick:"mycandlestick"
}

module.exports.chartType = chartType;