/**
 * 定义颜色
 */
var chartColor = {
    red : "#ff0000",//红色
    green : "#00ff00",//绿色
    blue : "#0000ff",//蓝色
    black : "#000000",//黑色
    white : "#ffffff",//白色
    yellow : "#ffff00",//黄色
    purple : "#ff00ff",//紫色
    cyan : "#00ffff"//青色
}

module.exports.chartColor = chartColor;