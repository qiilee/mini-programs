# wechatapp-demo
一个微信小程序的上手学习小demo,包括常用组件使用，ajax获取数据，模板使用，路由等，通过一些手段将underscore引入到项目中

小程序缺失功能
1 不同环境不同配置（既dev,test,production目前无法判断）

未解决问题  
<image/>组件怎么让高度自适应
