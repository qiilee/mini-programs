function ajaxUrl(){
    var url = "https://ichuanyi.com/m.php";
    return url; 
}

function cdnUrl(){
  var cdnUrl = "https://image1.ichuanyi.cn/";
  return cdnUrl;
}

module.exports = {
  ajaxUrl: ajaxUrl,
  cdnUrl:cdnUrl
}