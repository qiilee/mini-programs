Page({
    data: {
        detail: {
            id: "9514263",
            img: "http://img.alicdn.com/imgextra/i2/2225298358/TB2GPktawvA11Bjy0FfXXcVfVXa_!!2225298358.jpg",
            title: "6人团-熊出没12色油画棒蜡笔无毒可水洗",
            people: "6",
            newPrice: "8.50",
            oddPrice: "19.50"
        },
        countdown: {
            people: "2",
            time: "02: 01: 15"
        },
        lists: [{
            userImg: "http://wx.qlogo.cn/mmopen/PiajxSqBRaEJFSdgCbjibiblTKD8Bj89bbr4pxBsLJ33EWlR8kM0c3SUgsP5h6icfaBbU8IE9NmWibDUYNJXR5wqEeA/0",
            userName: "MeiMei",
            time: "2016-10-17 20:21:45",
            head: true
        },{
            userImg: "http://service.ipinbb.com:8080/ImageService/GetImage?imageName=200--200__group1__$$M00$$00$$22$$CgqAy1d2DXeAaGNJAAAfRtkzz_U025.jpg",
            userName: "A姜丽有明堂酒栈",
            time: "2016-10-18 14:02:40"
        },{
            userImg: "http://service.ipinbb.com:8080/ImageService/GetImage?imageName=200--200__group1__$$M00$$00$$20$$CgoSrFd1042AQ33XAAAkPbFm9lE019.jpg",
            userName: "水无痕",
            time: "2016-10-18 16:18:58"
        },{
            userImg: "http://service.ipinbb.com:8080/ImageService/GetImage?imageName=200--200__group1__$$M00$$00$$21$$CgoSrFd11uuANZ9CAAAiNkLjzo8843.jpg",
            userName: "白天不懂夜的黑",
            time: "2016-10-18 17:56:33"
        },{
            userImg: "http://service.ipinbb.com:8080/ImageService/GetImage?imageName=180--180__group1__$$M00$$00$$1B$$CgqAy1dw3yeABA4zAAAgGGU5gYc632.jpg",
            userName: "谁欠谁幸福",
            time: "2016-10-18 18:38:39"
        }]
    },
    onReady: function () {
        wx.setNavigationBarTitle({
            title: '团详情'
        })
    }
})