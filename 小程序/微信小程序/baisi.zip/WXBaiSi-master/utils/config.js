module.exports = {
    BaseURL:"http://api.budejie.com/api/api_open.php"
};