# 微信小程序－美容

### 说明：

实现服务展示，服务详情，预约，技师列表，技师详情等功能，特色：
- 图标tab

### 数据接口:

使用本地数据

### 目录结构：

- pages — 存放项目页面文件
- images — 存放项目图片文件
- utils — 存放本地数据和日期格式化文件

### 项目截图：

https://www.getweapp.com/project?projectId=583aa05be8ff074c22472f35

### 源码地址：

https://github.com/getweapp/weapp-meirong
