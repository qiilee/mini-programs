
var actions = [];

var animations = [];

var timelines = [
  {
    "iType": 0, 
    "element_id": "body_32b1346f42ce0867", 
    "data": {
      "type": 0, 
      "t": {
        "rv": 0, 
        "rp": 0, 
        "wa": 0, 
        "de": 0, 
        "st": 1, 
        "du": 1, 
        "es": 0
      }, 
      "d": {}
    }, 
    "id": "M_6e201cd5fd0d4182", 
    "animations": []
  }
];

coolsite360.DATA[__wxRoute] = {
   animations:animations,
   actions:actions,
   timelines:timelines
};

