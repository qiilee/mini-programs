
var actions = [];

var animations = [];

var timelines = [
  {
    "iType": 0, 
    "element_id": "body_9ab45c7551a37757", 
    "data": {
      "type": 0, 
      "t": {
        "rv": 0, 
        "rp": 0, 
        "wa": 0, 
        "de": 0, 
        "st": 1, 
        "du": 1, 
        "es": 0
      }, 
      "d": {}
    }, 
    "id": "M_07bb73fa21b77589", 
    "animations": []
  }
];

coolsite360.DATA[__wxRoute] = {
   animations:animations,
   actions:actions,
   timelines:timelines
};

