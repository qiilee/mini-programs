
var actions = [];

var animations = [];

var timelines = [
  {
    "iType": 0, 
    "element_id": "body_dac738d0954545d4", 
    "data": {
      "type": 0, 
      "t": {
        "rv": 0, 
        "rp": 0, 
        "wa": 0, 
        "de": 0, 
        "st": 1, 
        "du": 1, 
        "es": 0
      }, 
      "d": {}
    }, 
    "id": "M_af79ddf6c4f79155", 
    "animations": []
  }
];

coolsite360.DATA[__wxRoute] = {
   animations:animations,
   actions:actions,
   timelines:timelines
};

