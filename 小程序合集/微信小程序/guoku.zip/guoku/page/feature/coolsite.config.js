
var actions = [];

var animations = [];

var timelines = [
  {
    "data": {
      "type": 0, 
      "t": {
        "rv": 0, 
        "rp": 0, 
        "wa": 0, 
        "de": 0, 
        "st": 1, 
        "du": 1, 
        "es": 0
      }, 
      "d": {}
    }, 
    "element_id": "body_6a8999d4a4c66f33", 
    "iType": 0, 
    "id": "M_d07d8945c3928aee", 
    "animations": []
  }
];

coolsite360.DATA[__wxRoute] = {
   animations:animations,
   actions:actions,
   timelines:timelines
};

