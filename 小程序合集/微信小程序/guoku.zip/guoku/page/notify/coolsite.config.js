
var actions = [];

var animations = [];

var timelines = [
  {
    "iType": 0, 
    "element_id": "body_c6d3487791f6635f", 
    "data": {
      "type": 0, 
      "t": {
        "rv": 0, 
        "rp": 0, 
        "wa": 0, 
        "de": 0, 
        "st": 1, 
        "du": 1, 
        "es": 0
      }, 
      "d": {}
    }, 
    "id": "M_a31726d4c0188b40", 
    "animations": []
  }
];

coolsite360.DATA[__wxRoute] = {
   animations:animations,
   actions:actions,
   timelines:timelines
};

