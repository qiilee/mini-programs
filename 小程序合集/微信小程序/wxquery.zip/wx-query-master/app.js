var wxQuery = require('./utils/wxquery.js');

App({
    /** 全局引入wxQuery */
    wxQuery : wxQuery,
    $ : wxQuery.$
})