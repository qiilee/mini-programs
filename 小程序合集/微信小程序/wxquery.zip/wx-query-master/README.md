wxQuery
-------

	对 Page.prototype.setData() 函数的封装
    
![image](https://raw.githubusercontent.com/stephenml/wx-query/master/images/demo.gif)

## Thanks
* 云淡风轻