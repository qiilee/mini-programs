# 微信小程序－图片懒加载

### 说明：

实现商品懒加载特效。

### 数据接口:

- https://api.getweapp.com/vendor/lightstao/searchkey
- https://api.getweapp.com/vendor/lightstao/product/search


### 开发环境：

微信web开发者工具 v0.11.112301


### 感谢：

项目原始模板由jackyshan提供：https://github.com/jackyshan/yangtaowechatapp，由小小小基于其模板上添加图片懒加载特效