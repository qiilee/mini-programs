# weapp-wechat-nearby-master

> 功能点：轮播；列表，下拉刷新上拉加载更多；地图；网络请求；数据绑定等
> 文本仿照了 找事吧app 附近三公里功能，并感谢找事吧数据的提供。考虑到数据的私密性，本文贴出的代码并没有贴出请求URL，敬请谅解。
> 本文基于微信小程序公测版，IDE：微信开发者工具 0.10.102800

效果图如下：

![enter image description here](http://img.blog.csdn.net/20161115163622331)

具体的介绍分析，放在了csdn的博客中，博客地址：[http://blog.csdn.net/u010635353/article/details/53173633](http://blog.csdn.net/u010635353/article/details/53173633)
