module.exports = {
    toplist: {
        toplist1: [
            {
                id: 19723756,
                src: "http://p3.music.126.net/TkNqminF5jTCzk12Mf5Acg==/7744959906898786.jpg ",
                name: "云音乐飙升榜",
                updatetime: "每天更新"
            }, {
                id: 3779629,
                src: "http://p3.music.126.net/LRtxrRfP3g6Gn3vyvWEXOw==/7808731581312441.jpg ",
                name: "云音乐新歌榜",
                updatetime: "每天更新"
            }, {
                id: 2884035,
                src: "http://p4.music.126.net/LgoU8FreFrdLvSY3ZTFu5g==/2902710698975677.jpg ",
                name: "云音乐原创歌曲榜",
                updatetime: "每周四更新"
            }, {
                id: 3778678,
                src: "http://p3.music.126.net/eSXJexcoihfSe8ERgOdMnQ==/2920302885027135.jpg ",
                name: "云音乐热歌榜",
                updatetime: "每周四更新"
            }
        ],
        toplist2: [{
            id: 112504,
            src: "http://p4.music.126.net/1MzrbY-8PvvDgFah3uCMig==/5739450697092148.jpg ",
            name: "中国TOP音乐榜榜（港台榜）",
            updatetime: "每周一更新"
        }, {
            id: 64016,
            src: "http://p4.music.126.net/QjYkd-QFVv6e-34_gyePCw==/1269935930127361.jpg ",
            name: "中国TOP音乐榜榜（内地榜）",
            updatetime: "每周一更新"
        }, {
            id: 4395559,
            src: "http://p4.music.126.net/2YXiTGtOn2GwSl4iUfQOHQ==/5985741301868412.jpg ",
            name: "华语金曲榜",
            updatetime: "每周一更新"
        },
        {
            id: 71385702,
            src: "http://p4.music.126.net/RLM4r1_a9XUSQ0GO58QsXQ==/2924700931525267.jpg ",
            name: "云音乐ACG音乐榜",
            updatetime: "每周四更新"
        }, {
            id: 71384707,
            src: "http://p3.music.126.net/WafOU0LOjAerguvkja7J9Q==/7791139395263203.jpg ",
            name: "云音乐古典音乐榜",
            updatetime: "每周四更新"
        }, {
            id: 10520166,
            src: "http://p4.music.126.net/5z9yfCsZ7bvTKUNN-jxqow==/7856010581293779.jpg ",
            name: "云音乐电音榜",
            updatetime: "每周四更新"
        }, {
            id: 180106,
            src: "http://p3.music.126.net/sNdnRpXmCwFsAj2EX4-OVw==/5666882929660308.jpg ",
            name: "UK排行榜周榜",
            updatetime: "每周四更新"
        }, {
            id: 60198,
            src: "http://p3.music.126.net/koBrRZkYaqrXfep4zr420g==/6058309069460360.jpg ",
            name: "美国Billboard周榜",
            updatetime: "每周四更新"
        }, {
            id: 3812895,
            src: "http://p4.music.126.net/VxjQ-nTkeAIcFdXSKbNMug==/1240249116178109.jpg ",
            name: "Beatport全球电子舞曲榜",
            updatetime: "每周四更新"
        }, {
            id: 27135204,
            src: "http://p4.music.126.net/kn5Nb3HA-8c3y-KYVVDk-w==/6623458046388376.jpg ",
            name: "法国 NRJ Vos Hits 周榜",
            updatetime: "每周四更新"
        }, {
            id: 21845217,
            src: "http://p3.music.126.net/UN8g4epoFk-I4DV_C8w32A==/2922501907760617.jpg ",
            name: "KTV唛榜",
            updatetime: "每周四更新"
        }, {
            id: 11641012,
            src: "http://p4.music.126.net/hM7U6d25M3oj7tajgcnRjg==/5790028232058309.jpg ",
            name: "iTunes榜",
            updatetime: "每周四更新"
        }, {
            id: 60131,
            src: "http://p3.music.126.net/vEaaj-nECgH7kjBRT1DlQA==/5684475115701565.jpg ",
            name: "日本Oricon周榜",
            updatetime: "每周四更新"
        }, {
            id: 3733003,
            src: "http://p4.music.126.net/9YSGHPRdVazKSiNGl3uwpg==/5920870115713082.jpg ",
            name: "韩国Melon排行榜周榜",
            updatetime: "每周四更新"
        }]
    }
}