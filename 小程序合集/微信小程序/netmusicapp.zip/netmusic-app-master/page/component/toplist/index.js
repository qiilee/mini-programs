var toplist=require("../../../utils/toplist.js");
Page({
    data:{
        toplist:toplist.toplist
    },
    onLoad:function(){

    }
})