# wx-gesture-lock
微信小程序的手势密码  
使用https://github.com/lvming6816077/H5lock 这个库。  

<p style="margin:auto; text-align:center"><img src="screenshot/screenshot.jpg" width="400px"/></p>
