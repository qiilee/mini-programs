App({
    onLaunch: function () {
    },
    onShow: function () {
        //console.log('App Show')
    },
    onHide: function () {
        //console.log('App Hide')
    },
    globalData: {
        newsHref: "https://wedengta.com/wxnews/",
    }
})
