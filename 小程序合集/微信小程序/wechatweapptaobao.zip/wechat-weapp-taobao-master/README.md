# wechat-weapp-taobao
微信小程序demo 仿手机淘宝

# 这是一个微信小程序的demo ,仿淘宝,模仿手机 淘宝做的,近期会不断更新中....
![微信小程序-仿淘宝之首页](image/weapp_taobao_home.png) 

![微信小程序-仿淘宝之首页2（最下面部分采用了服务器请求接口）](image/weapp_taobao_2.png) 

![微信小程序-仿淘宝之我的淘宝登录](image/weapp_taobao_mytb.png) 

# 喜欢就star吧,谢谢 
