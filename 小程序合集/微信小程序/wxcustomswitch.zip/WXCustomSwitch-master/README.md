# WXCustomSwitch
微信小程序自定义 Switch 组件模板

可自定义颜色
![效果演示](./sources/SwitchDemo.gif)