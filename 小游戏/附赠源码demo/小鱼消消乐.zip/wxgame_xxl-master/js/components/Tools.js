
export const pubsub = new Laya.EventDispatcher();