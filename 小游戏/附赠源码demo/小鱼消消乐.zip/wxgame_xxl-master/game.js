import "./weapp-adapter.js";
import "./libs/laya.core.js";
import "./libs/laya.wxmini.js";
import "./libs/laya.webgl.js";
import "./libs/laya.ani.js";
import "./libs/laya.filter.js";
import "./libs/laya.ui.js";

import Main from './js/Main.js';

new Main();