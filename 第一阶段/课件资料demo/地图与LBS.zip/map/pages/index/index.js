Page({
  data:{
    // text:"这是一个页面"
  }
})