//app.js
const AV = require('/utils/av-weapp-min.js'); 
AV.init({
  appId: 'pTf5kDMERjsFopcOt9mO4C3e-gzGzoHsz', 
  appKey: 'YRb4tW0mekPrVHpCHzokI3Bf'
})
App({
  
})