## 运行截图
<img src="http://oht7mjuah.bkt.clouddn.com/%E9%A6%96%E9%A1%B5.png" width="270" height="480"/>
<img src="http://oht7mjuah.bkt.clouddn.com/timer-over.png" width="270" height="480" />
<img src="http://oht7mjuah.bkt.clouddn.com/timer.png" width="270" height="480" />
<img src="http://oht7mjuah.bkt.clouddn.com/wallet.png" width="270" height="480" />
<img src="http://oht7mjuah.bkt.clouddn.com/charge.png" width="270" height="480" />
<img src="http://oht7mjuah.bkt.clouddn.com/me.png" width="270" height="480" />
<img src="http://oht7mjuah.bkt.clouddn.com/password.png" width="270" height="480"/>
<img src="http://oht7mjuah.bkt.clouddn.com/warn-fill.png" width="270" height="480"/>
<img src="http://oht7mjuah.bkt.clouddn.com/mark.png" width="270" height="480"/>

## 本地运行
~~~
git clone https://github.com/MiceLiD/ofo-applet.git
~~~

微信开发者工具选择目录为ofo

## 非法域名报错
微信开发者工具中请关闭校验域名，或把www.easy-mock.com添加到域名配置中

## 提示
调试看效果请用真机，开发者工具定位有bug

[本小程序教程链接](http://www.jianshu.com/p/68e3b8927a77)